import os
exit(os.system("inarysh ./inary-script.ish"))
