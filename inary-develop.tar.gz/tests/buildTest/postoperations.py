#!/usr/bin/env python3


def postInstall():
    print("hello post install")


def postRemove():
    print("hello post remove")


def preInstall():
    print("hello pre install")


def preRemove():
    print("hello pre remove")
