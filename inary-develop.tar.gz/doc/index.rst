.. -*- coding: utf-8 -*-

%%%%%%%%%%%%%%
Inary Handbook
%%%%%%%%%%%%%%


Welcome to inary documentation.

This documentation contains information about inary package management for everyone, \
from end users to developers, even though you won't read it.

.. _an_introduction: Documentation Tree

.. toctree::
   :maxdepth: 2

   about.rst
   installation.rst
   commands/index.rst
   basicsofinary/index.rst
   advaced/index.rst
   faqs.rst
   glossary.rst

Bu belgeleme AGPL-3 ile lisanslanmıştır.
