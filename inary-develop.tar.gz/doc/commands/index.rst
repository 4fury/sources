.. -*- coding: utf-8 -*-

%%%%%%%%%%%%%%
Inary Commands
%%%%%%%%%%%%%%

.. toctree::
   :maxdepth: 0

   ./blame.rst
   ./build.rst
   ./check.rst
   ./configure-pending.rst
   ./delete-cache.rst
   ./delta.rst
   ./emerge.rst
   ./emergeup.rst
   ./fetch.rst
   ./graph.rst
   ./info.rst
   ./install.rst
   ./help.rst
   ./history.rst
   ./index_cmd.rst
   ./rebuild-db.rst
   ./remove.rst
   ./remove-orphaned.rst
   ./search.rst
   ./search-file.rst
   ./sysconf.rst
   ./upgrade.rst
   ./repo-commands.rst
   ./list-commands.rst
