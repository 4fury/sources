.. -*- coding: utf-8 -*-

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Components and System Relations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
