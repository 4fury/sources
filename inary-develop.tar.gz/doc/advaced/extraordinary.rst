.. -*- coding: utf-8 -*-

%%%%%%%%%%%%%%%%%%%%%%%%
Extraordinary Situations
%%%%%%%%%%%%%%%%%%%%%%%%
