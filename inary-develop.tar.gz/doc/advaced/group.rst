.. -*- coding: utf-8 -*-

%%%%%%%%%%%%%%%%%%
Application Groups
%%%%%%%%%%%%%%%%%%
