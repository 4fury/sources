.. -*- coding: utf-8 -*-

%%%%%%%%%%%%%%%%
Advaced of INARY
%%%%%%%%%%%%%%%%

In this pages, I will explain how could you be a inary gru.

.. toctree::
    :maxdepth: 0

    component.rst
    group.rst
    extraordinary.rst
