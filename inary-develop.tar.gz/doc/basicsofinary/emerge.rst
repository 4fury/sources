.. -*- coding: utf-8 -*-

In the previous section, I explained how to add the repository to install the package. I continue assuming \
that you have `try_repo` on your system.

===========================================
How to build a package to install? (emerge)
===========================================

I mentioned before that we have two different repo types. We use the emerge command to install packages \
from source repositories. Although things seem to have shifted to a little more gentoo logic, we can build \
and install packages by using the emerge command by building the necessary dependencies.


===========================================
How to build a package to install? (emerge)
===========================================
