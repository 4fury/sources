#ifndef __install_h
#define __install_h

#include <glib.h>

gchar* archive_install (const gchar *path);
void   archive_create  (const gchar *path);

#endif
