# -*- coding: utf-8 -*-


CREDITS = """
Many thanks to everyone who has commented on sK1/Skencil, submitted 
suggestions or bug reports, helped in the testing or 
contributed to sK1/Skencil with code or through mini payments.

In particular, thanks to (in alphabetical order):

Aaron Digulla
Alexander Prokoudine
André Pascual
Andrey Kiselev
Andy Thaller
Antoon Pardon
Aurelien Gateau
Bernhard Reiter
Brian Bartholomew
Cesar Brod
Christian Rose
Christian Schwarz
Christof Ecker
Claudio Bettio
David Boddie
Eric Jacobs
Eric Marston
Esteban Manchado Velázquez
Frank Koormann
Frederic Lepied
Frédéric Toussaint
Gregor Hoffleit
Han-Wen Nienhuys
Jan-Oliver Wagner
Jeffrey Boser
John Shumway
Joonas Paalasmaa
Konrad Hinsen
Lopo Pizarro
Louis Desjardins
Lukasz Pankowski
Mark Rose
Martin Glaser
Mauro Colorio
Maxim Barabash
Michael Dunstan
Michael Loßin
Michel Robitaille
Olof S Kylander
Otto Tronarp
Panos Katsaloulis
Paul Giotta
Philippe Blayo
Philipp Matthias Hahn
Ralf Ahlbrink
Shin Kwan Shik
Simon Budig
Steinar Knutsen
Tamito KAJIYAMA
Tessa Lau
Thomas Gellekum
Thomas Leonard
Valek Fillipov
Valentin Ungureanu
Wanderlei Antonio Cavassin
Yves Ceccone
"""
