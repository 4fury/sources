#!/usr/bin/env python
# -*- mode: python; coding: koi8-r -*-


import gtk


##----------------------------------------------------------------------
##----------------------------------------------------------------------


class PropsWindow(gtk.Dialog):


    def __init__(self, parent):

        gtk.Dialog.__init__(self, 'dialog', parent.main_window,
                            gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                            (gtk.STOCK_OK,     gtk.RESPONSE_OK,
                             gtk.STOCK_APPLY,  gtk.RESPONSE_APPLY,
                             gtk.STOCK_CLOSE,  gtk.RESPONSE_REJECT))

        notebook = gtk.Notebook()
        self.vbox.pack_start(notebook, expand=True, fill=True)

        table = gtk.Table(len(parent.text_widget.scroll_properties.__dict__), 2)
        table.set_row_spacings(4)
        table.set_col_spacings(4)

        vbox = gtk.VBox()
        vbox.pack_start(table, expand=False, fill=False)

        label = gtk.Label('')
        label.set_text_with_mnemonic('_Scrolling')
        notebook.append_page(vbox, label)

        for i in parent.text_widget.scroll_properties.__dict__:
            prop = parent.text_widget.scroll_properties.__dict__[i]
            n = prop.place
            label = gtk.Label(prop.label)
            label.set_use_underline(True)
            label.set_alignment(0.0, 0.5)
            table.attach(label, 0, 1, n, n+1, xpadding=4, ypadding=1)
            spin = gtk.SpinButton()
            spin.set_range(prop.min_value, prop.max_value)
            spin.set_increments(1, 4)
            spin.set_value(prop.value)
            spin.connect('value_changed', self.spin_value_changed_2, i)
            table.attach(spin, 1, 2, n, n+1, xpadding=4, ypadding=1)
            label.set_mnemonic_widget(spin)

        for i in parent.text_widget.scroll_type.__dict__:
            prop = parent.text_widget.scroll_type.__dict__[i]
            n = prop.place
            check = gtk.CheckButton(prop.label)
            check.set_active(prop.value)
            check.connect('toggled', self.check_toggled, i)
            table.attach(check, 0, 2, n+3, n+4, xpadding=4, ypadding=1)


        radio1 = gtk.RadioButton(label='Don\'t use mouse for scroll')
        if parent.text_widget.mouse_scroll_type == 0: radio1.set_active(True)
        radio1.connect('toggled', self.radio_toggled, 0)
        table.attach(radio1, 0, 2, 5, 6, xpadding=4, ypadding=1)
        radio2 = gtk.RadioButton(group=radio1,
                                 label='Use mouse for step scrolling')
        if parent.text_widget.mouse_scroll_type == 1: radio2.set_active(True)
        radio2.connect('toggled', self.radio_toggled, 1)
        table.attach(radio2, 0, 2, 6, 7, xpadding=4, ypadding=1)
        radio3 = gtk.RadioButton(group=radio1,
                                 label='Use mouse for page scrolling')
        if parent.text_widget.mouse_scroll_type == 2: radio3.set_active(True)
        radio3.connect('toggled', self.radio_toggled, 2)
        table.attach(radio3, 0, 2, 7, 8, xpadding=4, ypadding=1)


        table = gtk.Table(len(parent.text_widget.text_properties.__dict__), 2)
        table.set_row_spacings(4)
        table.set_col_spacings(4)

        vbox = gtk.VBox()
        vbox.pack_start(table, expand=False, fill=False)

        label = gtk.Label('')
        label.set_text_with_mnemonic('_Text')
        notebook.append_page(vbox, label)

        for i in parent.text_widget.text_properties.__dict__:
            prop = parent.text_widget.text_properties.__dict__[i]
            n = prop.place
            label = gtk.Label(prop.label)
            label.set_use_underline(True)
            label.set_alignment(0.0, 0.5)
            label.set_justify(gtk.JUSTIFY_LEFT)
            table.attach(label, 0, 1, n, n+1, xpadding=4, ypadding=1)
            spin = gtk.SpinButton()
            spin.set_range(prop.min_value, prop.max_value)
            spin.set_increments(1, 4)
            spin.set_value(prop.value)
            spin.connect('value_changed', self.spin_value_changed, i)
            table.attach(spin, 1, 2, n, n+1, xpadding=4, ypadding=1)
            label.set_mnemonic_widget(spin)

        self.scroll_properties = {}
        self.scroll_type = {}
        self.mouse_scroll_type = None
        self.text_properties = {}

        self.show_all()

##----------------------------------------------------------------------

    def check_toggled(self, w, name):
        self.scroll_type[name] = w.get_active()

##----------------------------------------------------------------------

    def radio_toggled(self, w, n):
        self.mouse_scroll_type = n

##----------------------------------------------------------------------

    def spin_value_changed(self, w, name):
        self.text_properties[name] = w.get_value_as_int()

##----------------------------------------------------------------------

    def spin_value_changed_2(self, w, name):
        self.scroll_properties[name] = w.get_value_as_int()

##----------------------------------------------------------------------
##----------------------------------------------------------------------
