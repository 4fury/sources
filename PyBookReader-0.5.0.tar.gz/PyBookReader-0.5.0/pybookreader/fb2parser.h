/* fb2parser.h */

#ifndef __FB2PARSER_H__
#define __FB2PARSER_H__

#define BUF_SIZE 1024

#define DESCRIPTION_BUFFER 1
#define TEXT_BUFFER 2
#define BINARY_BUFFER 3

/* types of bookmark */
#define BOOKMARK_TYPE 0
#define LINK_TYPE 10
#define NOTE_TYPE 11
#define IMAGE_TYPE 20
#define STRONG_TYPE 30
#define EMPHASIS_TYPE 31
#define NAMED_STYLE_TYPE 32

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  int type;  /* type */

  /*  offsets (in characters) */
  int start; /* start */
  int end;   /* end */

  char id[BUF_SIZE]; /* for binary and link id */

  int link_start;
  int link_end;

} FB2Mark;

typedef struct {
  char *buffer;
  size_t buffer_size;
  int current_index;
  char id[BUF_SIZE];
  char content_type[BUF_SIZE];

} FB2Binary;

typedef struct {

  /* body */
  char *text;
  /* ��������� ���������� */
  size_t text_buffer_size;
  int text_current_index;
  /* current index of utf-8 string (in characters)*/
  int utf8_current_index;

  /* annotation */
  char *description;
  /* ��������� ���������� */
  size_t description_buffer_size;
  int description_current_index;

  /* first-name + midle-name + last-name + nickname */
  char author[BUF_SIZE];
  /* book-title */
  char name[BUF_SIZE];
  /* genre(s) (with NULL terminated) */
  char *genres[BUF_SIZE];

  int num_genres;

  /* marks (with NULL terminated) */
  FB2Mark *marks[BUF_SIZE];
  /* num of bookmarks */
  int num_marks;

  int current_buffer; /* DESCRIPTION_BUFFER or TEXT_BUFFER or BINARY_BUFFER */

  /* binary content */
  FB2Binary *binaries[BUF_SIZE];
  int num_binaries;

  char cover_href[BUF_SIZE];

  /* links */
  //FB2Link *links[BUF_SIZE];
  //int num_links;

} FB2Content;

FB2Content *parseFile(char *filename);
void freeFB2 (FB2Content *fb);


#ifdef __cplusplus
}
#endif

#endif /* __FB2PARSER_H__ */
