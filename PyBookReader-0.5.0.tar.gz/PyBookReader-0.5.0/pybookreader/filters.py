#!/usr/bin/env python
# -*- mode: python; coding: koi8-r -*-

import re

filters = {
    'internal_filter_1': 'Internal filter 1 (new line repairs)',
    'internal_filter_2': 'Internal filter 2 (remove leading spaces)',
    'internal_filter_3': 'Internal filter 3 (leading space paragraph)',
    'internal_filter_4': 'Internal filter 4 (TeX paragraph)',
    'internal_filter_5': 'Internal filter 5 (add tabs to begin)',
}

def internal_filter_1(data, bookmarks=None, charset='utf-8'):
    out=[]
    begin=0

    pat = re.compile('^\-+\s*(\w)', re.U)
    for l in data.split('\n'):
        s=unicode(l.rstrip(), charset) # rstrip ?

        if s == '':
            out.append('\n')
            begin=1
            continue

        c=s[-1]

        if c == '-' and s[-2].isalpha():
            #s=unicode(s, charset)[:-1].encode(charset)
            s=s[:-1]
            end_space=''
        else:
            end_space=' '

        mo = pat.search(s)
        if s[0].isspace() \
           or (begin and not s[0].islower()) \
           or (mo and mo.group(1).isupper()):
            out.append('\n\t%s%s' % (s.lstrip().encode(charset), end_space))
        else:
            out.append('%s%s' % (s.encode(charset), end_space))

        begin=0
        if c in ('.', '!', '?', '\'', '\"', ':'):
            begin=1

    out.append('\n')

    return ''.join(out)

##----------------------------------------------------------------------

def internal_filter_2(data, bookmarks=None, charset='utf-8'):

##     print bookmarks
##     text_offset = 0
##     buffer_offset = 0
##     mark_index = 0
##     if bookmarks:
##         current_mark_offset = bookmarks[mark_index]

    out = []
    for l in data.split('\n'):
##         text_offset += len(l)+1
        s = l.lstrip()+'\n'
        out.append(s)

##         if bookmarks and current_mark_offset >= 0: # have current_mark_offset
##             buffer_offset += len(s)
##             if text_offset > current_mark_offset:
##                 print '!!!', text_offset, current_mark_offset
##                 bookmarks[mark_index] = buffer_offset
##                 mark_index += 1
##                 if mark_index < len(bookmarks):
##                     current_mark_offset = bookmarks[mark_index]
##                 else:
##                     current_mark_offset = -1

    return ''.join(out)

##----------------------------------------------------------------------

def internal_filter_3(data, bookmarks=None, charset='utf-8'):
    out = []
    newline = True

    for l in data.split('\n'):
        s = l.rstrip()
        if s == '':
            out.append('\n')
            newline = True
            continue

        if s[0].isspace() or newline:
            s = ' '.join(s.split())
            out.append('\n\t%s' % s)
        else:
            s = ' '.join(s.split())
            out.append(' %s' % s)
        newline = False

    out.append('\n')

    return ''.join(out)

##----------------------------------------------------------------------

def internal_filter_4(data, bookmarks=None, charset='utf-8'):
    out = []
    begin = ''
    for l in data.split('\n'):
        s = l.strip()
        if s == '':
            out.append('\n')
            begin = '\t'
            continue

        out.append(begin + ' '.join(s.split()))
        begin = ' '

    out.append('\n')

    return ''.join(out)

##----------------------------------------------------------------------

def internal_filter_5(data, bookmarks=None, charset='utf-8'):

    out = []
    for l in data.split('\n'):
        s = '\t' + l.lstrip()+'\n'
        out.append(s)

    return ''.join(out)

##----------------------------------------------------------------------

if __name__ == '__main__':

    import sys, locale

    def usage():

        print 'usage:', sys.argv[0], 'filer file'
        print 'possible filters:'
        for f in filters:
            print f, '-', filters[f]
        sys.exit(1)

    if len(sys.argv) != 3:
        usage()

    import filters as self

    if not hasattr(self, sys.argv[1]):
        usage()

    locale.setlocale(locale.LC_ALL, '')
    enc = locale.getlocale()[1]
    func = getattr(self, sys.argv[1])

    print func(open(sys.argv[2]).read(),  bookmarks=None, charset=enc)


