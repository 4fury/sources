#!/usr/bin/env python
# -*- mode: python; coding: koi8-r -*-

import types, traceback

##----------------------------------------------------------------------

class Property:
    pass

##----------------------------------------------------------------------

class MainProperties:

    main_properties_list = {
        # <name>                            <type> <default value>
        'width'                           : ['int',   600      ],
        'height'                          : ['int',   400      ],
        'bookmarks_manager_width'         : ['int',   600      ],
        'bookmarks_manager_height'        : ['int',   400      ],
        'bookmarks_manager_paned_position': ['int',   200      ],
        'bookmarks_manager_hide_cover'    : ['int',   0        ],
        'bookmarks_manager_hide_bookmarks': ['int',   0        ],
        'bookmarks_manager_show_category' : ['str',   ''       ],
        'book_info_width'                 : ['int',   600      ],
        'book_info_height'                : ['int',   400      ],
        'book_info_bookmarks_paned_pos'   : ['int',   200      ],
        'hide_toolbar'                    : ['int',   0        ],
        'hide_statusbar'                  : ['int',   0        ],
        'hide_scrollbar'                  : ['int',   1        ],
        'font'                            : ['str',   'Normal' ],
        'fg_color'                        : ['str',   '#000000'],
        'bg_color'                        : ['str',   '#ffffff'],
        'bookmark_tag_color'              : ['str',   '#ff0000'],
        'link_tag_color'                  : ['str',   '#0000ff'],
        'speed'                           : ['float', 20.0     ],
        #'filename'                        : ['str',   ''       ],
        'file_select_path'                : ['str',   ''       ],
        'toolbar_style'                   : ['str',   'both'   ],
        #OpenFileDialog.file_select_path]
        }

    def __init__(self):
        for p in self.main_properties_list:
            prop = Property()
            prop.type = self.main_properties_list[p][0]
            prop.value = self.main_properties_list[p][1]
            #self.__dict__[p] = prop
            setattr(self, p, prop)

    def save_properties(self, fd):
        for i in self.__dict__:
            # skip if filename is None
            #if i == 'filename' and not self.filename.value:
            #    pass
            # skip if file_select_path is None
            if i == 'file_select_path' and not self.file_select_path.value:
                pass
            else:
                type = self.__dict__[i].type
                if type == 'int':
                    value = int(self.__dict__[i].value)
                elif type == 'float':
                    value = float(self.__dict__[i].value)
                else: # str
                    value = self.__dict__[i].value
                fd.write('%s=%s\n' % (i, str(value)))

    def set_properties(self, properties):
        for i in self.__dict__:
            if properties.has_key(i):
                type = self.__dict__[i].type
                try:
                    if  type == 'int':
                        self.__dict__[i].value = int(properties[i])
                    elif type == 'float':
                        self.__dict__[i].value = float(properties[i])
                    else:
                        self.__dict__[i].value = properties[i]
                except:
                    traceback.print_exc()
                    pass

##----------------------------------------------------------------------

class TextProperties:

    text_properties_list = {
        'text_left_margin'        : [8, '_Left margin:',        0,    0,  40],
        'text_right_margin'       : [8, '_Right margin:',       1,    0,  40],
        'text_pixels_above_lines' : [0, 'Pixels _above lines:', 2,  -20,  40],
        'text_pixels_below_lines' : [0, 'Pixels _below lines:', 3,  -20,  40],
        'text_pixels_inside_wrap' : [0, 'Pixels _inside wrap:', 4,  -20,  40],
        'tabs_width'              : [8, '_Tabs width:',         5,    1,  32],
        #'indent'                  : [8, 'Indentation:',          5, -100, 100],
        }

    def __init__(self):
        for p in self.text_properties_list:
            prop = Property()
            prop.value = self.text_properties_list[p][0]
            prop.label = self.text_properties_list[p][1]
            prop.place = self.text_properties_list[p][2]
            prop.min_value = self.text_properties_list[p][3]
            prop.max_value = self.text_properties_list[p][4]
            #self.__dict__[p] = prop
            setattr(self, p, prop)

    def save_properties(self, fd):
        for i in self.__dict__:
            fd.write('%s=%s\n' % (i, self.__dict__[i].value))

    def set_properties(self, properties):
        for i in self.__dict__:
            if properties.has_key(i):
                try:
                    self.__dict__[i].value = int(properties[i])
                except:
                    traceback.print_exc()
                    pass

##----------------------------------------------------------------------

class ScrollProperties:

    scroll_properties_list = {
        'auto_scroll_increment'    : [1, '_Auto scroll increment:',     0, 1, 20],
        'key_scroll_increment'     : [4, '_Key scroll step increment:', 1, 1, 20],
        'key_scroll_page_increment': [8, 'K_ey scroll page increment:', 2, 1, 40],
        }

    def __init__(self):
        for p in self.scroll_properties_list:
            prop = Property()
            prop.value = self.scroll_properties_list[p][0]
            prop.label = self.scroll_properties_list[p][1]
            prop.place = self.scroll_properties_list[p][2]
            prop.min_value = self.scroll_properties_list[p][3]
            prop.max_value = self.scroll_properties_list[p][4]
            #self.__dict__[p] = prop
            setattr(self, p, prop)

    def save_properties(self, fd):
        for i in self.__dict__:
            fd.write('%s=%s\n' % (i, self.__dict__[i].value))

    def set_properties(self, properties):
        for i in self.__dict__:
            if properties.has_key(i):
                try:
                    self.__dict__[i].value = int(properties[i])
                except:
                    traceback.print_exc()
                    pass

##----------------------------------------------------------------------

class ScrollType:

    # <name> <value> <label> <place>
    scroll_type_list = {
        'smooth_step_scrolling': [1, 'Smooth _step scrolling', 0],
        'smooth_page_scrolling': [1, 'Smooth _page scrolling', 1]
        }

    def __init__(self):
        for p in self.scroll_type_list:
            prop = Property()
            prop.value = self.scroll_type_list[p][0]
            prop.label = self.scroll_type_list[p][1]
            prop.place = self.scroll_type_list[p][2]
            #self.__dict__[p] = prop
            setattr(self, p, prop)

    def save_properties(self, fd):
        for i in self.__dict__:
            fd.write('%s=%s\n' % (i, int(self.__dict__[i].value)))

    def set_properties(self, properties):
        for i in self.__dict__:
            if properties.has_key(i):
                try:
                    self.__dict__[i].value = int(properties[i])
                except:
                    traceback.print_exc()
                    pass

##----------------------------------------------------------------------

if __name__ == '__main__':
    import sys
    mp = MainProperties()
    #mp.filename.value = 'aaabbbccc'
    #print mp.filename.value
    mp.save_properties(sys.stdout)
    tp = TextProperties()
    tp.save_properties(sys.stdout)
    sp = ScrollProperties()
    sp.save_properties(sys.stdout)
    st = ScrollType()
    st.save_properties(sys.stdout)
##     for i in mp.__dict__:
##         print i, mp.__dict__[i].value
##         #print i, eval('mp.%s.value' % i)
##         if i == 'filename' \
##                and not eval('mp.%s.value' % i):
##             print 'aaa'


