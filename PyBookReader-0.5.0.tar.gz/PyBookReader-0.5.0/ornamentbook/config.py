#!/usr/bin/env python
# -*- mode: python; coding: koi8-r; -*-
# (c) Con Radchenko mailto:lankier@gmail.com

import os

program_name = 'OrnamentBook'
program_version = '0.5'

config_dir = os.path.expanduser('~/.pybr')
config_file = os.path.join(config_dir, 'ornamentbook.conf')
iface_file = os.path.join(config_dir, 'ornamentbook-iface.conf')
user_skin_dir = os.path.join(config_dir, 'skins')


