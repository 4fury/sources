#!/usr/bin/env python
# -*- mode: python; coding: koi8-r -*-


import sys
import os
from distutils.core import setup, Extension
from distutils.command.install_data import install_data

from pybookreader.config import program_version

BUILD_FB2_SUPPORT = 1


class my_install_data(install_data):
    # for install data files to library dir
    def run(self):
        #need to change self.install_dir to the actual library dir
        install_cmd = self.get_finalized_command('install')
        self.install_dir = getattr(install_cmd, 'install_lib')
        return install_data.run(self)

ext_modules = []

## build FictionBook2 support
if BUILD_FB2_SUPPORT:
    xml2_libs = os.popen('xml2-config --libs', 'r').read().split()
    xml2_cflags = os.popen('xml2-config --cflags', 'r').read().split()
    ext = Extension('pybookreader.fb2wrap',
                    ['pybookreader/fb2parser.c',
                     'pybookreader/fb2parser_wrap.c'],
                    extra_compile_args = xml2_cflags,
                    extra_link_args = xml2_libs,
                    )
    ext_modules.append(ext)

setup(
    name = 'PyBookReader',
    version = program_version,
    url = 'http://pybookreader.narod.ru',
    author = 'Con Radchenko',
    author_email = 'pybookreader@narod.ru',
    description = 'PyBookReader is a PyGTK-based GUI book reader.',
    license = 'GPL',
    scripts = ['pybr', 'ob'],
    packages = ['pybookreader', 'pybookreader.dictclient', 'ornamentbook'],
    ext_modules = ext_modules,
    cmdclass = {'install_data': my_install_data},
    data_files = [('pybookreader',
                   ['pybookreader/pybookreader.glade']),
                  ('pybookreader/dictclient',
                   ['pybookreader/dictclient/pygtkdict.glade']),
                  ('ornamentbook',
                   ['ornamentbook/ornamentbook.glade',
                    'ornamentbook/propsdialog.glade']),
                  ('ornamentbook/skins',
                   ['ornamentbook/skins/golden.jpg']),
                  ('ornamentbook/hyph_dicts',
                   ['ornamentbook/hyph_dicts/hyph_de.dic',
                    'ornamentbook/hyph_dicts/hyph_en.dic',
                    'ornamentbook/hyph_dicts/hyph_es.dic',
                    'ornamentbook/hyph_dicts/hyph_fr.dic',
                    'ornamentbook/hyph_dicts/hyph_it.dic',
                    'ornamentbook/hyph_dicts/hyph_ru.dic',
                    'ornamentbook/hyph_dicts/hyph_uk.dic',
                    'ornamentbook/hyph_dicts/langs.txt',
                    'ornamentbook/hyph_dicts/README.ru']),
                  ]
    )

